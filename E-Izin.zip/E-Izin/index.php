<!DOCTYPE html>
<html>
      <head>
            <meta charset="utf-8">
            <title>E-Surat</title>
            <link rel="stylesheet" href="css/bootstrap.min.css"/>
            <link rel="stylesheet" href="css/custom.css"/>
            <style type="text/css">
              
            </style>
      </head>
      <body>
            <div class="container">
                  <div class="row">
                        <div class="col-md-12">
                        
<h2 class="index-header">E-Surat Izin Sekolah</h2>
<div class="row">
    <div class="col-md-4 ">
        <div id="content-slider">
            <img src="img/tut.png" class="img" alt="Slideshow 1" >
        </div>
    </div>
    <div class="col-md-6 form">
        
		<p class="text-left-bold">Ketentuan:</p>
		<p>1.Silahkan Bagi Kirim foto dengan format jpg,png,jpeg,dll.</p>
		<p>2.Silahkan Beri Nama File Nama_kelas_absent.png(tergantung file).</P>
		<p>3.Isi semua data diri di kolom input.</p>
		<p>4.Pastikan semua inputan valid dan sesuai.</p>
             
                <div class="text-left" style="padding-right:15px;">
                   <a href="input.php"><input type="submit" name="submit" class="btn btn-success btn-lg" value="masuk"></a>
                
            </div>
        </form>
    </div>
</div>

                        </div>
                  </div>
            </div>
            <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
            <script type="text/javascript" src="js/jquery-cycle.min.js"></script>
            <script type="text/javascript">
            $(document).ready(function() {
            $('#content-slider').cycle({
                  fx: 'fade',
                  speed: 1000,
                  timeout: 500
            });
            });
            </script>
      </body>
</html>
