<?php

$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "db_surat";
$connect    = mysqli_connect($host, $user, $password, $database)


?>